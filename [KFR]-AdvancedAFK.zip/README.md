

1. Drag the files into your corebot directory
AdvancedAfk.js -> Addons
59Utils.js -> Main Directory (Always update this file)
2. UPDATE 59Utils.js THIS IS IMPORTANT
4. boot up your bot

Features:

Customizable Messages
Afk Role
Cacheless Afk Nickname
Channel Notifications
Timed Afk Sessions
Afk List

Commands:

Afk - Mark yourself as AFK
AfkList - List all AFK people
